/* This class was written by Lance Marsland on 10/7/20
with the purpose of creating a GUI for my homework planner project */

//package code (organization)
package com.lancemarsland.apProjectFinal;

//import statements
import java.io.*;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

//class statement
public class Assignment extends ArrayList {
    //initializing variables
    private String subject;
    private String assignmentName;
    private String description;
    private LocalDate dueDate;
    private String newAssignment;

    //Constructors
    public Assignment(String subject, String assignmentName, String description, LocalDate dueDate, String newAssignment) {
        this.subject = subject;
        this.assignmentName = assignmentName;
        this.description = description;
        this.dueDate = dueDate;
    }
    //overloading constructors (polymorphism)
    public Assignment(String subject, String assignmentName, String description, String dueDate) {
        this.subject = subject;
        this.assignmentName = assignmentName;
        this.description = description;
        this.setDueDate(dueDate); //setDueDate method

    }
    //file io toString method
    @Override
    public String toString(){ //returns arrayList data
        return "Assignment{" +
                "AssignmentName=" + assignmentName + '\'' +
                "Subject=" + subject + '\'' +
                " Description=" + description + '\'' +
                " Due Date=" + dueDate +
                "}\n";
    }

    //Accessor methods
    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getAssignmentName() {
        return assignmentName;
    }

    public void setAssignmentName(String assignmentName) {
        this.assignmentName = assignmentName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public LocalDate getDueDate() {
        return dueDate;
    }

    public void setDueDate(String dueDate) {
        //date time formatter for due date
        this.dueDate = LocalDate.parse(dueDate, DateTimeFormatter.ofPattern("MM/dd/yyyy"));
    }

    //method to find remaining days
    public int getDays() {
        LocalDate today = LocalDate.now(); //creating LocalDate
        Period period = Period.between(today, this.dueDate); //period between today and due date
        if (period.isZero()) //if 0 days return 0
            return 0;
        else if (period.isNegative()) //if negative days return 0
            return 0;
        else    //else return days
            return period.getDays();

    }



}
