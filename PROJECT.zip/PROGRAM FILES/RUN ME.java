/* This class was written by Lance Marsland on 10/7/20
with the purpose of creating a GUI for my homework planner project */

//package code (organization)
package com.lancemarsland.apProjectFinal;

//java imports for GUI
import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

//Extending class to JFrame
public class homeworkPlannerGUI extends JFrame {
    //initializing JFrame parts
    private JPanel panelTop;
    private JPanel panelLeft;
    private JPanel panelRight;
    private JList listAssignments;
    private JButton buttonNew;
    private JButton buttonSave;
    private JTextField textSubject;
    private JTextField textAssignmentName;
    private JTextField textDescription;
    private JTextField textDueDate;
    private JLabel labelDaysRemaining;
    private JLabel labelDays;
    private JButton buttonDelete;
    private JPanel panelMain;
    private JLabel Subject;
    private JLabel AssignmentName;
    private JLabel Description;
    private JLabel DueDate;
    private JButton buttonSaveFile;
    private JButton loadFileButton;
    private ArrayList<Assignment> assignments;
    private DefaultListModel listAssignmentsModel;


    //Screen Code
    homeworkPlannerGUI() {
        super("Homework Planner Project"); //window title
        this.setContentPane(this.panelMain); //what panel is shown
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //close operation
        this.pack(); //compiles screen together
        assignments = new ArrayList<Assignment>(); //initializing arrayList
        listAssignmentsModel = new DefaultListModel(); //creating default swing list model
        listAssignments.setModel(listAssignmentsModel);  //attaching swing model to assignment list
        buttonSave.setEnabled(false); //save button disabled by default
        buttonDelete.setEnabled(false); //delete button disabled by default
        setSize(800, 400); //setting screen size
        setResizable(false); //locking screen size (non-resizable)


        //Initializing buttons and calling methods

        //New Button
        buttonNew.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                buttonNewClick(e); //calling button method
            }
        });

        //Save Button
        buttonSave.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                buttonSaveClick(e); //calling button method
            }
        });

        //Delete Button
        buttonDelete.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                buttonDeleteClick(e); //calling button method
            }
        });

        //List Selection
        listAssignments.addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                listPeopleSelection(e); //calling button method
            }
        });

        //Save File Button (File io)
        buttonSaveFile.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                buttonSaveFileClick(e); //calling button method
            }
        });

        //Load file button (File io)
        loadFileButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                buttonLoadFileClick(e); //calling button method
            }
        });
    }


    //Button Methods

    //Save File Click Method
    public void buttonSaveFileClick(ActionEvent e) {
        System.out.println("save"); //testing button functionality
        try { //try catch for errors
            FileOutputStream writeData = new FileOutputStream("saveFile.txt"); //write data to this file
            ObjectOutputStream writeStream = new ObjectOutputStream(writeData); //write object data

            writeStream.writeObject(assignments); //arraylist assignments
            writeStream.flush(); //flushing output stream
            writeStream.close(); //closing

        } catch (IOException e1) { //catching error
            e1.printStackTrace(); //printing error message
        }
    }

    //Print File Click Method
    public void buttonLoadFileClick(ActionEvent e) {
        System.out.println("print"); //testing button functionality
        try { //try catch for errors
            FileInputStream readData = new FileInputStream("saveFile.txt"); //take data from this file
            ObjectInputStream readStream = new ObjectInputStream(readData); //read data

            ArrayList assignments = (ArrayList<Assignment>) readStream.readObject(); //creating arraylist of data
            readStream.close(); //close

            System.out.println(assignments.toString()); //print out data, calling toString method
        } catch (IOException | ClassNotFoundException e1) { //catching error
            e1.printStackTrace(); //printing error message
        }
    }

    //New Assignment Click Method
    public void buttonNewClick(ActionEvent e) {
        Assignment a = new Assignment(
                "Math, Science, History, etc..",
                "New Assignment",
                "Brief description of the assignment",
                "12/30/2020"
        ); //adds example assignment when button is clicked
        assignments.add(a);
        refreshAssignmentsList(); //calling refresh method to update list
    }

    //Save Existing Assignment Click Method
    public void buttonSaveClick(ActionEvent e) {
        int assignmentNumber = listAssignments.getSelectedIndex(); //get index of selected assignment
        if (assignmentNumber >= 0) { //if assignment is selected (>=0)
            Assignment a = assignments.get(assignmentNumber); //get selected assignment

            //change the assignment details
            a.setSubject(textSubject.getText());
            a.setAssignmentName(textAssignmentName.getText());
            a.setDescription(textDescription.getText());
            a.setDueDate(textDueDate.getText());

            //calling refresh method to update list
            refreshAssignmentsList();
        }
    }

    //Delete Assignment Click Method
    public void buttonDeleteClick(ActionEvent e) {
        int selected = listAssignments.getSelectedIndex(); //gets index, -1 if no selection
        if (selected >= 0) { //if assignment is selected (>=0)
            Assignment a = assignments.get(selected); //get selected assignment
            assignments.remove(a); //remove assignment from arraylist
            refreshAssignmentsList(); //calling refresh method to update list
        }
    }


    //Select Assignment Click Method
    public void listPeopleSelection(ListSelectionEvent e) {
        int assignmentNumber = listAssignments.getSelectedIndex(); //gets index, -1 if no selection
        if (assignmentNumber >= 0) { //if assignment is selected (>=0)
            Assignment a = assignments.get(assignmentNumber); //get assignment

            //Display assignment details
            textSubject.setText(a.getSubject());
            textAssignmentName.setText(a.getAssignmentName());
            textDescription.setText(a.getDescription());
            textDueDate.setText(a.getDueDate().format(DateTimeFormatter.ofPattern("MM/dd/yyyy")));

            //Display remaining days to finish assignment
            labelDays.setText(Integer.toString(a.getDays()) + " days");

            //Enable Save and Delete buttons if assignment is selected
            buttonSave.setEnabled(true);
            buttonDelete.setEnabled(true);
        } else {
            //Disable buttons if no assignment is selected
            buttonSave.setEnabled(false);
            buttonDelete.setEnabled(false);
        }

    }

    /* Refresh List Method (updates visual list of assignments),
     removes elements from list and rebuilds with new elements */
    public void refreshAssignmentsList() {
        listAssignmentsModel.removeAllElements(); //removing assignments from list
        for (Assignment a : assignments) { //rebuilding list by adding assignments
            listAssignmentsModel.addElement(a.getAssignmentName());

        }
    }

    //Method for adding assignments
    public void addAssignment(Assignment a) {
        assignments.add(a); //adds assignment to list
        refreshAssignmentsList(); //calling refresh method to update list
    }

    //Main Method
    public static void main(String[] args) {

        //creating screen
        homeworkPlannerGUI screen = new homeworkPlannerGUI();
        screen.setVisible(true); //setting screen visible

        //adding default assignment to arrayList, this will show user how to fill text fields
        Assignment a = new Assignment("Math, Science, History, etc..", "New Assignment",
                "Brief description of the assignment", "12/30/2020");

        //Adding example assignment to screen
        screen.addAssignment(a); //calling add assignment method
    }

}



